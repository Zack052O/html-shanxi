# 陕西历史博物馆网站

## 介绍
本项目是陕西历史博物馆官方网站的前端部分，旨在为对陕西丰富文化遗产感兴趣的用户提供信息丰富且视觉上吸引人的体验。

## 布局分布
- **头部**: 包含博物馆的标志和导航链接。
- **导航栏**: 快速访问网站不同部分的链接。
- **轮播图**: 展示当前展览和活动的动态横幅。
- **内容区**: 关于展览、藏品和博物馆历史的详细信息。
- **页脚**: 包括联系信息和额外链接。

## 特色功能
- **响应式设计**: 适应各种屏幕尺寸以优化观看体验。
- **互动导航**: 平滑滚动至不同部分，提供无缝的用户体验。
- **动态内容**: 实时更新和动画，吸引访客。

## 样式亮点
- **优雅色调**: 反映博物馆美学的配色方案。
- **排版**: 精心挑选的字体，增强可读性和风格。
- **CSS动画**: 用户交互时激活的微妙效果。

## 导航功能
- **内部链接**: 可点击的标题，引导用户浏览网站。
- **返回顶部**: 一个悬浮按钮，让用户轻松返回页面顶部。
- **音乐控制**: 一个互动开关，用于播放或暂停背景音乐。

## 设置
要运行此项目，请下载`index.html`和`style.css`文件以及`img`，并在浏览器中打开html。

我们欢迎贡献和建议，以改善网站的用户体验。



## JS代码1--点击跳转/平滑动效
        // 点击
        function scrollToSection(sectionId) {
            document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
        }

        window.onscroll = function () {
            let sections = ['welcome-section', 'exhibitions-section', 'collections-section', 'about-section', 'visit-section', 'contact-section'];
            sections.forEach(section => {
                let element = document.getElementById(section);
                let position = element.getBoundingClientRect();
                if (position.top <= 150 && position.bottom >= 150) {
                    document.querySelectorAll('.side-nav-item').forEach(div => {
                        div.classList.remove('active');
                    });
                    document.querySelector(`.side-nav-item[onclick="scrollToSection('${section}')"]`).classList.add('active');
                }
            });
        };
        // 平滑滚动效果
        // 点击事件监听器。当点击链接时，它会阻止默认的跳转行为，
        // 并改为平滑滚动到页面中对应ID的元素点击事件监听器。
        document.querySelectorAll('nav a').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const sectionId = this.getAttribute('href');
                document.querySelector(sectionId).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
## JS代码1--点击跳转/平滑动效 解释
        
    简单来说，这段JavaScript代码负责两件事情：

    1. `scrollToSection` 函数：当用户点击导航条时，页面会平滑地滚动到相应的页面部分。
    2. `window.onscroll` 事件：当用户手动滚动页面时，代码会检查并高亮当前视图区域对应的导航条项目，以指示用户当前所在的页面位置。


    详细解释：
        这段JavaScript代码负责实现两个主要功能：平滑滚动到页面的特定部分，以及在滚动过程中更新侧边导航条的状态。
        （1）scrollToSection函数:
        这个函数接受一个sectionId参数，这是HTML元素的ID。当这个函数被调用时，它使用scrollIntoView方法使得带有这个ID的元素滚动到视口中。{ behavior: 'smooth' }这个选项确保了滚动是平滑的。
        （2）window.onscroll事件处理器:
        当用户滚动页面时，这个事件处理器被触发。它遍历一个包含所有主要页面部分ID的数组。

        对于数组中的每一个section，它获取对应元素的getBoundingClientRect方法返回的位置数据。这个方法返回元素的大小及其相对于视口的位置。
        然后，它检查元素的位置是否在视口的特定范围内（顶部位置小于或等于150px，并且底部位置大于或等于150px）。这通常意味着元素是在视口中并相对靠近中间位置。
        如果条件满足，它将遍历所有.side-nav-item类的元素，并移除它们的active类，这通常会改变它们的样式，如背景颜色或大小等，以表示它们不是当前激活的部分。
        最后，它会选择用户当前滚动到的部分对应的侧边导航条项，并给它添加active类，从而高亮当前激活的部分。
        这样，当用户点击侧边导航的某个项目时，页面会平滑滚动到对应的部分。同时，当用户滚动页面时，侧边导航的当前位置也会更新，从而为用户提供视觉上的反馈，告知他们目前所查看的页面内容。


## JS代码2--banner轮播图 
      //banner
        let slideIndex = 0;
        showSlides();

        function showSlides() {
            let i;
            let slides = document.getElementsByClassName("slide");
            let dots = document.getElementsByClassName("slide-buttons")[0].getElementsByTagName("span");
            for (i = 0; i < slides.length; i++) {
                slides[i].style.opacity = "0";
            }
            slideIndex++;
            if (slideIndex > slides.length) { slideIndex = 1 }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slides[slideIndex - 1].style.opacity = "1";
            dots[slideIndex - 1].className += " active";
            setTimeout(showSlides, 6000); // Change image every 3 seconds
        }

        function currentSlide(n) {
            slideIndex = n - 1;
            showSlides();
        }
## JS代码2--banner轮播图 解释
这段JavaScript代码实现了轮播图功能，包括自动播放和导航点（dots）的交互。下面是它的工作原理：

1. **初始化**:
   - `slideIndex`：用于跟踪当前显示的幻灯片索引。
   - `showSlides()`：一开始就被调用，用于启动轮播图。

2. **showSlides 函数**:
   - 获取所有幻灯片(`slides`)和导航点(`dots`)。
   - 将所有幻灯片的透明度设置为0，使它们不可见。
   - 增加`slideIndex`以移动到下一张幻灯片。如果索引超出了幻灯片数量，则将其重置为1，实现循环播放。
   - 清除所有导航点的`active`类，然后只给当前幻灯片对应的导航点添加`active`类。
   - 通过`setTimeout`设置轮播图每6秒自动切换到下一张幻灯片。

3. **currentSlide 函数**:
   - 这个函数用于手动切换到特定编号的幻灯片。
   - 它接受一个数字`n`作为参数，表示目标幻灯片的编号，并相应地设置`slideIndex`。
   - 然后调用`showSlides`函数来更新显示。

总体来说，这段代码通过控制幻灯片的透明度和定时器来实现自动轮播功能，同时通过导航点提供了手动控制幻灯片切换的能力。



## JS代码3--音乐控件
// 音乐
        let isMusicPlaying = true; // 设置音乐为默认播放状态
        const music = document.getElementById('background-music');
        const musicToggle = document.getElementById('music-toggle');

        // 尝试自动播放音乐
        music.play().catch(e => {
            console.log("Auto-play was prevented by the browser.");
            isMusicPlaying = false;
            musicToggle.textContent = '🔇'; // 更新为播放图标
        });

        musicToggle.addEventListener('click', function () {
            isMusicPlaying = !isMusicPlaying;

            if (isMusicPlaying) {
                music.play();
                this.textContent = '🎵'; // 切换到静音图标
            } else {
                music.pause();
                this.textContent = '🔇'; // 切换到播放图标
                stopMusicNotes();
            }
        });

        
        let musicNotesInterval = setInterval(createMusicNote, 300);

        function stopMusicNotes() {
            clearInterval(musicNotesInterval);
            musicNotesInterval = null;
        }
## JS代码3--音乐控件 解释
这段JavaScript代码实现了网页上背景音乐的播放控制以及与之相关的音符动效功能。具体来说：

1. **音乐播放控制**:
   - `isMusicPlaying`：一个标志变量，初始设为`true`，表示音乐默认应当处于播放状态。
   - `music`：获取页面上的`<audio>`元素。
   - `musicToggle`：获取控制音乐播放的按钮元素。

   在页面加载时，代码尝试通过`music.play()`开始播放音乐。如果浏览器阻止了自动播放（这是常见的浏览器行为），则捕获该异常，并更新`isMusicPlaying`标志以及按钮的文本。

2. **音乐播放按钮点击事件**:
   - 当用户点击音乐控制按钮时，`isMusicPlaying`的状态被切换。
   - 如果`isMusicPlaying`为`true`，表示音乐应当播放，按钮文本设置为静音图标(`🎵`)。
   - 如果`isMusicPlaying`为`false`，表示音乐应当暂停，按钮文本设置为播放图标(`🔇`)，并调用`stopMusicNotes`函数停止音符动效。

3. **音符动效**:
   - `musicNotesInterval`：一个定时器，用于定期创建音符动效。
   - `stopMusicNotes`函数：用于清除音符动效的定时器，停止创建新的音符。

总体而言，这段代码通过按钮控制背景音乐的播放与暂停，同时根据音乐的播放状态创建或停止音符动效，为用户提供了互动性较强的体验。